
import {FaFacebook,FaInstagram,FaTwitter} from "react-icons/fa"

function Footer(){
return(
<footer className="bg-gray-900 text-white py-10">
<div className="max-w-6xl mx-auto px-6 grid md:grid-cols-3 gap-8">

<div>
<h2 className="text-xl font-bold">Healthy Me</h2>
<p className="text-gray-400">Healthy food delivery platform</p>
</div>

<div>
<h3 className="font-semibold mb-2">Quick Links</h3>
<ul className="text-gray-400 space-y-2">
<li>Home</li>
<li>Benefits</li>
<li>Join Now</li>
</ul>
</div>

<div>
<h3 className="font-semibold mb-2">Contact</h3>
<p className="text-gray-400">support@healthyme.com</p>

<div className="flex gap-4 mt-3 text-xl">
<FaFacebook/>
<FaInstagram/>
<FaTwitter/>
</div>

</div>

</div>
</footer>
)
}

export default Footer
