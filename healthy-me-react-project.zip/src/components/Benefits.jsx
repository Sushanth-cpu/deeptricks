
import {FaClock,FaMoneyBillWave,FaTruck,FaLeaf,FaHeadset} from "react-icons/fa"

function Benefits(){

const data=[
{icon:<FaClock/>,title:"Flexible Hours",desc:"Work anytime"},
{icon:<FaMoneyBillWave/>,title:"Weekly Payments",desc:"Get paid weekly"},
{icon:<FaTruck/>,title:"Easy Delivery",desc:"Simple pickup"},
{icon:<FaLeaf/>,title:"Healthy Brand",desc:"Deliver healthy meals"},
{icon:<FaHeadset/>,title:"Support",desc:"24/7 help"}
]

return(
<section id="benefits" className="py-16">
<h2 className="text-center text-3xl font-bold mb-10">Benefits</h2>

<div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto px-6">

{data.map((item,i)=>(
<div key={i} className="bg-white shadow p-6 rounded text-center">
<div className="text-green-500 text-3xl flex justify-center mb-3">{item.icon}</div>
<h3 className="font-semibold">{item.title}</h3>
<p className="text-gray-500">{item.desc}</p>
</div>
))}

</div>
</section>
)
}

export default Benefits
