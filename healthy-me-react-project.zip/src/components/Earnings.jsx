
function Earnings(){
return(
<section className="py-16 bg-green-50">
<h2 className="text-center text-3xl font-bold mb-10">Earnings</h2>

<div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto px-6">

<div className="bg-white p-6 rounded shadow">
<h3 className="font-semibold">Daily Earnings</h3>
<p>Earn up to ₹1200 per day</p>
</div>

<div className="bg-white p-6 rounded shadow">
<h3 className="font-semibold">Incentives</h3>
<p>Bonuses for extra deliveries</p>
</div>

<div className="bg-white p-6 rounded shadow">
<h3 className="font-semibold">Flexible Schedule</h3>
<p>Work anytime</p>
</div>

</div>
</section>
)
}
export default Earnings
