
import {useState} from "react"

function JoinForm(){

const [form,setForm]=useState({name:"",phone:"",city:"",vehicle:""})

function handleChange(e){
setForm({...form,[e.target.name]:e.target.value})
}

function handleSubmit(e){
e.preventDefault()
alert("Application Submitted")
}

return(
<section className="py-16 bg-gray-100">
<h2 className="text-center text-3xl font-bold mb-10">Join as Delivery Partner</h2>

<form onSubmit={handleSubmit} className="max-w-xl mx-auto bg-white p-8 rounded shadow space-y-4">

<input name="name" placeholder="Full Name" className="w-full border p-3 rounded" onChange={handleChange}/>
<input name="phone" placeholder="Phone Number" className="w-full border p-3 rounded" onChange={handleChange}/>
<input name="city" placeholder="City" className="w-full border p-3 rounded" onChange={handleChange}/>

<select name="vehicle" className="w-full border p-3 rounded" onChange={handleChange}>
<option>Vehicle Type</option>
<option>Bike</option>
<option>Scooter</option>
</select>

<button className="bg-green-500 text-white w-full py-3 rounded">Apply Now</button>

</form>
</section>
)
}

export default JoinForm
