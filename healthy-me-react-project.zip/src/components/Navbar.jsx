
function Navbar(){
return(
<nav className="bg-white shadow sticky top-0">
<div className="max-w-7xl mx-auto px-6 py-4 flex justify-between">
<h1 className="text-2xl font-bold text-green-500">Healthy Me</h1>
<ul className="hidden md:flex gap-6">
<li><a href="#">Home</a></li>
<li><a href="#benefits">Benefits</a></li>
<li><a href="#how">How It Works</a></li>
<li><a href="#requirements">Requirements</a></li>
</ul>
<button className="bg-green-500 text-white px-4 py-2 rounded">Join Partner</button>
</div>
</nav>
)
}
export default Navbar
