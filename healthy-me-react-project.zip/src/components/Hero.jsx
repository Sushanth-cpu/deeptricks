
import { motion } from "framer-motion";

function Hero(){
return(
<section className="py-20 bg-green-50">
<div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-10 px-6 items-center">

<motion.div initial={{opacity:0,y:40}} animate={{opacity:1,y:0}}>
<h1 className="text-4xl font-bold mb-4">Earn While You Deliver Healthy Meals</h1>
<p className="text-gray-600 mb-6">Join Healthy Me and earn flexible income delivering nutritious meals.</p>
<button className="bg-green-500 text-white px-6 py-3 rounded">Start Delivering</button>
</motion.div>

<img src="https://cdn-icons-png.flaticon.com/512/2921/2921822.png" className="w-80 mx-auto"/>

</div>
</section>
)
}
export default Hero
