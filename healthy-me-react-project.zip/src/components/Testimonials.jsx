
function Testimonials(){
return(
<section className="py-16">
<h2 className="text-center text-3xl font-bold mb-10">Testimonials</h2>

<div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto px-6">

<div className="bg-white p-6 rounded shadow">
<p>"Healthy Me helped me earn extra income."</p>
<h4 className="mt-3 font-bold">Rahul Sharma</h4>
</div>

<div className="bg-white p-6 rounded shadow">
<p>"Flexible working hours are great."</p>
<h4 className="mt-3 font-bold">Arjun Patel</h4>
</div>

<div className="bg-white p-6 rounded shadow">
<p>"Support team is very helpful."</p>
<h4 className="mt-3 font-bold">Suresh Kumar</h4>
</div>

</div>
</section>
)
}
export default Testimonials
