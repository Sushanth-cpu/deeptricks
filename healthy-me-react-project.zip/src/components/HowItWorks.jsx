
function HowItWorks(){

const steps=["Sign Up","Upload Documents","Get Approved","Start Delivering"]

return(
<section id="how" className="py-16 bg-gray-100">
<h2 className="text-center text-3xl font-bold mb-10">How It Works</h2>

<div className="grid md:grid-cols-4 gap-6 max-w-6xl mx-auto px-6">

{steps.map((step,i)=>(
<div key={i} className="bg-white p-6 shadow rounded text-center">
<h3 className="text-green-500 font-bold mb-2">Step {i+1}</h3>
<p>{step}</p>
</div>
))}

</div>
</section>
)
}

export default HowItWorks
