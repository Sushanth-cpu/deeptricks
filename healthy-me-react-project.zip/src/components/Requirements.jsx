
function Requirements(){

const req=[
"Valid Driving License",
"Smartphone with Internet",
"Bike or Scooter",
"Identity Proof"
]

return(
<section id="requirements" className="py-16">
<h2 className="text-center text-3xl font-bold mb-10">Requirements</h2>

<div className="grid md:grid-cols-4 gap-6 max-w-6xl mx-auto px-6">

{req.map((r,i)=>(
<div key={i} className="bg-white shadow p-6 rounded text-center">
<p>{r}</p>
</div>
))}

</div>
</section>
)
}

export default Requirements
