
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Benefits from "./components/Benefits";
import HowItWorks from "./components/HowItWorks";
import Requirements from "./components/Requirements";
import Earnings from "./components/Earnings";
import Testimonials from "./components/Testimonials";
import JoinForm from "./components/JoinForm";
import Footer from "./components/Footer";

function App(){
return(
<div className="bg-gray-50">
<Navbar/>
<Hero/>
<Benefits/>
<HowItWorks/>
<Requirements/>
<Earnings/>
<Testimonials/>
<JoinForm/>
<Footer/>
</div>
)
}

export default App
