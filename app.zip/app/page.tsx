import { Navbar } from "@/components/landing/Navbar"
import { Hero } from "@/components/landing/Hero"
import { Benefits } from "@/components/landing/Benefits"
import { HowItWorks } from "@/components/landing/HowItWorks"
import { Requirements } from "@/components/landing/Requirements"
import { Earnings } from "@/components/landing/Earnings"
import { Testimonials } from "@/components/landing/Testimonials"
import { JoinForm } from "@/components/landing/JoinForm"
import { Footer } from "@/components/landing/Footer"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <Hero />
      <Benefits />
      <HowItWorks />
      <Requirements />
      <Earnings />
      <Testimonials />
      <JoinForm />
      <Footer />
    </main>
  )
}
