"use client"

import { motion } from "framer-motion"
import { FiUserPlus, FiUpload, FiCheckCircle, FiTruck } from "react-icons/fi"

const steps = [
  {
    icon: FiUserPlus,
    step: "01",
    title: "Sign Up",
    description: "Fill out the simple registration form with your basic details and contact information.",
  },
  {
    icon: FiUpload,
    step: "02",
    title: "Upload Documents",
    description: "Submit your driving license, identity proof, and vehicle documents for verification.",
  },
  {
    icon: FiCheckCircle,
    step: "03",
    title: "Get Approved",
    description: "Our team reviews your application within 24-48 hours and approves eligible partners.",
  },
  {
    icon: FiTruck,
    step: "04",
    title: "Start Delivering",
    description: "Download the app, go online, and start accepting delivery orders to earn money.",
  },
]

export function HowItWorks() {
  return (
    <section id="how-it-works" className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center max-w-2xl mx-auto mb-16"
        >
          <span className="text-primary font-medium text-sm uppercase tracking-wider">Simple Process</span>
          <h2 className="mt-3 text-3xl sm:text-4xl font-bold text-foreground text-balance">
            How to Get Started
          </h2>
          <p className="mt-4 text-muted-foreground leading-relaxed">
            Join our delivery team in just four simple steps
          </p>
        </motion.div>

        {/* Steps Timeline */}
        <div className="relative">
          {/* Connection Line */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-0.5 bg-border -translate-y-1/2" />
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="relative"
              >
                {/* Step Card */}
                <div className="bg-card p-6 rounded-2xl border border-border text-center relative z-10 h-full">
                  {/* Step Number */}
                  <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4 relative">
                    <step.icon className="w-7 h-7 text-primary-foreground" />
                    <span className="absolute -top-1 -right-1 w-6 h-6 bg-foreground text-background rounded-full text-xs font-bold flex items-center justify-center">
                      {step.step}
                    </span>
                  </div>
                  
                  <h3 className="text-lg font-semibold text-foreground mb-2">{step.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{step.description}</p>
                </div>

                {/* Arrow for desktop */}
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2 z-20">
                    <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                      <span className="text-primary">→</span>
                    </div>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
