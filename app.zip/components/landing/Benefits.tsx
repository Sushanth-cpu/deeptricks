"use client"

import { motion } from "framer-motion"
import { FiClock, FiDollarSign, FiPackage, FiHeart, FiHeadphones } from "react-icons/fi"

const benefits = [
  {
    icon: FiClock,
    title: "Flexible Working Hours",
    description: "Choose when you want to work. Morning, evening, or weekends—you decide your schedule.",
  },
  {
    icon: FiDollarSign,
    title: "Weekly Payments",
    description: "Get paid every week directly to your bank account. No waiting for months to receive your earnings.",
  },
  {
    icon: FiPackage,
    title: "Easy Pickup & Delivery",
    description: "Simple pickup process from health-focused restaurants with clear delivery instructions.",
  },
  {
    icon: FiHeart,
    title: "Health-focused Brand",
    description: "Be part of a mission to promote healthy eating habits and well-being in your community.",
  },
  {
    icon: FiHeadphones,
    title: "24/7 Support Team",
    description: "Our dedicated support team is always available to help you with any issues or questions.",
  },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5 },
  },
}

export function Benefits() {
  return (
    <section id="benefits" className="py-20 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center max-w-2xl mx-auto mb-16"
        >
          <span className="text-primary font-medium text-sm uppercase tracking-wider">Why Join Us</span>
          <h2 className="mt-3 text-3xl sm:text-4xl font-bold text-foreground text-balance">
            Benefits of Being a Delivery Partner
          </h2>
          <p className="mt-4 text-muted-foreground leading-relaxed">
            Enjoy exclusive perks and a supportive environment that helps you succeed
          </p>
        </motion.div>

        {/* Benefits Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {benefits.map((benefit, index) => (
            <motion.div
              key={benefit.title}
              variants={itemVariants}
              className={`group relative bg-background p-6 rounded-2xl border border-border hover:border-primary/50 transition-all hover:shadow-lg ${
                index === 4 ? "lg:col-span-1 sm:col-span-2 lg:col-start-2" : ""
              }`}
            >
              <div className="w-12 h-12 bg-secondary rounded-xl flex items-center justify-center mb-4 group-hover:bg-primary/10 transition-colors">
                <benefit.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">{benefit.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{benefit.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
