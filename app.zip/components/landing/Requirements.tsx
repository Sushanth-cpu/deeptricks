"use client"

import { motion } from "framer-motion"
import { FiCreditCard, FiSmartphone, FiNavigation, FiUser } from "react-icons/fi"

const requirements = [
  {
    icon: FiCreditCard,
    title: "Valid Driving License",
    description: "A valid two-wheeler or four-wheeler driving license issued by the government.",
  },
  {
    icon: FiSmartphone,
    title: "Smartphone with Internet",
    description: "Android or iOS smartphone with active internet connection to use the delivery app.",
  },
  {
    icon: FiNavigation,
    title: "Bike or Scooter",
    description: "Own vehicle in good condition for efficient and timely deliveries.",
  },
  {
    icon: FiUser,
    title: "Identity Proof",
    description: "Government-issued ID like Aadhaar card, PAN card, or passport for verification.",
  },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, scale: 0.9 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { duration: 0.4 },
  },
}

export function Requirements() {
  return (
    <section id="requirements" className="py-20 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center max-w-2xl mx-auto mb-16"
        >
          <span className="text-primary font-medium text-sm uppercase tracking-wider">What You Need</span>
          <h2 className="mt-3 text-3xl sm:text-4xl font-bold text-foreground text-balance">
            Basic Requirements
          </h2>
          <p className="mt-4 text-muted-foreground leading-relaxed">
            Make sure you have these essentials before applying
          </p>
        </motion.div>

        {/* Requirements Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {requirements.map((req) => (
            <motion.div
              key={req.title}
              variants={itemVariants}
              className="group bg-background p-6 rounded-2xl border border-border text-center hover:shadow-lg transition-all hover:-translate-y-1"
            >
              <div className="w-16 h-16 bg-secondary rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/10 transition-colors">
                <req.icon className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">{req.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{req.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
