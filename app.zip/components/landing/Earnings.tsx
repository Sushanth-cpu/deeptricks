"use client"

import { motion } from "framer-motion"
import { FiTrendingUp, FiGift, FiCalendar } from "react-icons/fi"

const earningsData = [
  {
    icon: FiTrendingUp,
    title: "Average Daily Earnings",
    value: "₹800 - ₹1,500",
    description: "Earn based on the number of deliveries you complete each day.",
    highlight: true,
  },
  {
    icon: FiGift,
    title: "Incentives & Bonuses",
    value: "Up to ₹5,000",
    description: "Additional earnings through peak hour bonuses and weekly incentives.",
    highlight: false,
  },
  {
    icon: FiCalendar,
    title: "Flexible Schedules",
    value: "24/7 Availability",
    description: "Work during breakfast, lunch, dinner, or any time that suits you.",
    highlight: false,
  },
]

export function Earnings() {
  return (
    <section className="py-20 bg-background relative overflow-hidden">
      {/* Background Accent */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center max-w-2xl mx-auto mb-16"
        >
          <span className="text-primary font-medium text-sm uppercase tracking-wider">Earning Potential</span>
          <h2 className="mt-3 text-3xl sm:text-4xl font-bold text-foreground text-balance">
            Maximize Your Income
          </h2>
          <p className="mt-4 text-muted-foreground leading-relaxed">
            Competitive pay structure designed to reward your hard work
          </p>
        </motion.div>

        {/* Earnings Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          {earningsData.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className={`relative p-8 rounded-2xl ${
                item.highlight
                  ? "bg-primary text-primary-foreground"
                  : "bg-card border border-border"
              }`}
            >
              {item.highlight && (
                <div className="absolute top-4 right-4">
                  <span className="bg-primary-foreground/20 text-primary-foreground text-xs font-medium px-3 py-1 rounded-full">
                    Most Popular
                  </span>
                </div>
              )}
              
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${
                item.highlight ? "bg-primary-foreground/20" : "bg-secondary"
              }`}>
                <item.icon className={`w-6 h-6 ${item.highlight ? "text-primary-foreground" : "text-primary"}`} />
              </div>
              
              <h3 className={`text-lg font-semibold mb-2 ${item.highlight ? "" : "text-foreground"}`}>
                {item.title}
              </h3>
              
              <div className={`text-3xl font-bold mb-3 ${item.highlight ? "" : "text-primary"}`}>
                {item.value}
              </div>
              
              <p className={`text-sm leading-relaxed ${
                item.highlight ? "text-primary-foreground/80" : "text-muted-foreground"
              }`}>
                {item.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Additional Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-12 bg-card border border-border rounded-2xl p-8"
        >
          <div className="grid md:grid-cols-4 gap-6 text-center">
            <div>
              <div className="text-2xl font-bold text-foreground">₹25,000+</div>
              <div className="text-sm text-muted-foreground mt-1">Monthly avg. earnings</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-foreground">10-15</div>
              <div className="text-sm text-muted-foreground mt-1">Orders per day</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-foreground">₹50-80</div>
              <div className="text-sm text-muted-foreground mt-1">Per delivery</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-foreground">Weekly</div>
              <div className="text-sm text-muted-foreground mt-1">Payment cycle</div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
