"use client"

import { motion } from "framer-motion"
import { FiArrowRight, FiPlay } from "react-icons/fi"
import Link from "next/link"

export function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center pt-16 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-20 right-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-0 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
          >
            <div className="inline-flex items-center gap-2 bg-secondary px-4 py-2 rounded-full mb-6">
              <span className="w-2 h-2 bg-primary rounded-full animate-pulse" />
              <span className="text-sm font-medium text-secondary-foreground">Now hiring delivery partners</span>
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-tight text-balance">
              Earn While You Deliver{" "}
              <span className="text-primary">Healthy Meals</span>
            </h1>
            
            <p className="mt-6 text-lg text-muted-foreground max-w-xl leading-relaxed">
              Join the Healthy Me delivery team and enjoy flexible working hours, competitive pay, and the satisfaction of delivering nutritious meals to health-conscious customers.
            </p>

            <div className="mt-8 flex flex-wrap gap-4">
              <Link
                href="#join"
                className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-8 py-4 rounded-full font-medium hover:opacity-90 transition-all hover:gap-3"
              >
                Start Delivering
                <FiArrowRight />
              </Link>
              <button className="inline-flex items-center gap-2 bg-card border border-border px-8 py-4 rounded-full font-medium text-foreground hover:bg-secondary transition-colors">
                <FiPlay className="text-primary" />
                Watch Video
              </button>
            </div>

            {/* Stats */}
            <div className="mt-12 grid grid-cols-3 gap-8">
              <div>
                <div className="text-3xl font-bold text-foreground">5K+</div>
                <div className="text-sm text-muted-foreground">Active Partners</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-foreground">₹25K</div>
                <div className="text-sm text-muted-foreground">Avg. Monthly Earnings</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-foreground">50+</div>
                <div className="text-sm text-muted-foreground">Cities Covered</div>
              </div>
            </div>
          </motion.div>

          {/* Right Content - Illustration */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="relative"
          >
            <div className="relative w-full aspect-square max-w-lg mx-auto">
              {/* Main Circle */}
              <div className="absolute inset-0 bg-secondary rounded-full" />
              
              {/* Delivery Person Illustration */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="relative">
                  {/* Scooter Body */}
                  <div className="w-48 h-32 bg-primary rounded-2xl relative">
                    {/* Delivery Box */}
                    <div className="absolute -top-8 left-1/2 -translate-x-1/2 w-24 h-16 bg-accent rounded-lg flex items-center justify-center">
                      <span className="text-accent-foreground font-bold text-xs">HEALTHY ME</span>
                    </div>
                    {/* Wheels */}
                    <div className="absolute -bottom-4 left-4 w-12 h-12 bg-foreground rounded-full border-4 border-card" />
                    <div className="absolute -bottom-4 right-4 w-12 h-12 bg-foreground rounded-full border-4 border-card" />
                  </div>
                  
                  {/* Person */}
                  <div className="absolute -top-20 left-1/2 -translate-x-1/2">
                    <div className="w-16 h-16 bg-primary/80 rounded-full" />
                    <div className="w-8 h-4 bg-primary mx-auto -mt-2 rounded" />
                  </div>
                </div>
              </div>

              {/* Floating Elements */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity }}
                className="absolute top-10 right-10 bg-card p-3 rounded-xl shadow-lg"
              >
                <span className="text-2xl">🥗</span>
              </motion.div>
              <motion.div
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 3, repeat: Infinity, delay: 0.5 }}
                className="absolute bottom-20 left-10 bg-card p-3 rounded-xl shadow-lg"
              >
                <span className="text-2xl">🥑</span>
              </motion.div>
              <motion.div
                animate={{ y: [0, -15, 0] }}
                transition={{ duration: 3, repeat: Infinity, delay: 1 }}
                className="absolute top-1/2 right-0 bg-card p-3 rounded-xl shadow-lg"
              >
                <span className="text-2xl">🍎</span>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
